#!/bin/bash
if [ "$#" -ge "2" ]
then
list="`cat $2`"
for x in $list
do
echo -e ${x/$1/"\e[1m$1\e[m"}
done
fi