list="`cat $1`"
for i in $list
do
    echo $i
done

